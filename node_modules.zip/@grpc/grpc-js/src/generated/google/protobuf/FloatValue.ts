// Original file: null


export interface FloatValue {
  'value'?: (number | string);
}

export interface FloatValue__Output {
  'value': (number);
}
